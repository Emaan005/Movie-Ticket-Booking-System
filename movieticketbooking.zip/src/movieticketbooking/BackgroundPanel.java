package movieticketbooking;

import javax.swing.*;
import java.awt.*;

public class BackgroundPanel extends JFrame {
    public BackgroundPanel(String imagePath) {
        setTitle("Movie Ticket Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);
        setResizable(true);  // Allow resizing of the window
        setLocationRelativeTo(null);

        // Create a custom panel to handle the background image scaling
        ImagePanel imagePanel = new ImagePanel(imagePath);
        imagePanel.setLayout(new BorderLayout()); // Layout for the background image panel

        // Set GridBagLayout for the center panel
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false); // Transparent panel for the text

        // Create the text label
        JLabel centerLabel = new JLabel("Welcome to the Movie Ticket Booking System!", SwingConstants.CENTER);
        centerLabel.setForeground(Color.WHITE); // Set text color to white
        centerLabel.setFont(new Font("Arial", Font.BOLD, 25)); // Set font size

        // Set the background color for the text label
        centerLabel.setOpaque(true); // Make label opaque to show background color
        centerLabel.setBackground(new Color(0, 0, 0, 250)); // Semi-transparent black background (adjust the alpha as needed)
        centerLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding around the text

        // Add text in the center of the grid
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 250, 0); // Add padding at the top (adjust as needed)
        centerPanel.add(centerLabel, gbc);

        // Add the center panel to the background image panel
        imagePanel.add(centerPanel, BorderLayout.CENTER);

        // Button Panel with increased button sizes
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        buttonPanel.setOpaque(false);

        // Adjust the vertical spacing for the buttons to move them down
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 60, 60)); // Center the buttons and adjust vertical spacing

        // Create and style buttons
        JButton loginButton = new JButton("Login");
        styleButton(loginButton);
        JButton registerButton = new JButton("Register");
        styleButton(registerButton);
        JButton cancelBookingButton = new JButton("Cancel Booking");
        styleButton(cancelBookingButton);

        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(cancelBookingButton);

        imagePanel.add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        loginButton.addActionListener(e -> LoginPanel.showLogin());
        registerButton.addActionListener(e -> RegisterPanel.showRegister());
        cancelBookingButton.addActionListener(e -> CancelBookingPanel.showCancelBooking());

        setContentPane(imagePanel); // Set content pane to the background with buttons
    }

    // Helper method to style the buttons
    private void styleButton(JButton button) {
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 20)); // Increased font size
        button.setPreferredSize(new Dimension(200, 60)); // Increased button size to 1.5x
    }

    // Custom JPanel to scale the background image
    private static class ImagePanel extends JPanel {
        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            backgroundImage = new ImageIcon(imagePath).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Scale the background image to fit the panel
            int width = getWidth();
            int height = getHeight();
            g.drawImage(backgroundImage, 0, 0, width, height, this);
        }
    }
}
