package movieticketbooking;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

public class BookingPanel {

    public static void showBookingOptions(String username) {
        JFrame bookingFrame = createBackgroundFrame("Movie Booking - Welcome " + username);

        // Title
        JLabel titleLabel = new JLabel("Select Theater and Movie", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        bookingFrame.add(titleLabel, BorderLayout.NORTH);

        // Panel for theater selection
        JPanel theaterPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        theaterPanel.setBorder(BorderFactory.createTitledBorder(null, "Select Theater",
                2, 2, new Font("Arial", Font.BOLD, 14), Color.WHITE));
        theaterPanel.setOpaque(false);

        try (Connection conn = DatabaseConnection.getConnection()) {
            String theaterQuery = "SELECT TheaterID, TheaterName FROM Theaters";
            PreparedStatement pstmt = conn.prepareStatement(theaterQuery);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int theaterID = rs.getInt("TheaterID");
                String theaterName = rs.getString("TheaterName");

                JButton theaterButton = new JButton(theaterName);
                styleButton(theaterButton);
                theaterButton.addActionListener(e -> showMoviesForTheater(username, theaterID, theaterName));
                theaterPanel.add(theaterButton);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching theaters: " + e.getMessage());
        }

        bookingFrame.add(theaterPanel, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton("Back");
        styleButton(backButton);
        backButton.addActionListener(e -> bookingFrame.dispose());
        JPanel backPanel = new JPanel();
        backPanel.setOpaque(false);
        backPanel.add(backButton);
        bookingFrame.add(backPanel, BorderLayout.SOUTH);

        bookingFrame.setLocationRelativeTo(null); // Center the frame
        bookingFrame.setVisible(true);
    }

    private static void showMoviesForTheater(String username, int theaterID, String theaterName) {
        JFrame movieFrame = createBackgroundFrame("Movies at " + theaterName);

        // Title
        JLabel titleLabel = new JLabel("Select a Movie", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        movieFrame.add(titleLabel, BorderLayout.NORTH);

        // Panel for movie selection
        JPanel moviePanel = new JPanel(new GridLayout(2, 3, 10, 10));
        moviePanel.setBorder(BorderFactory.createTitledBorder(null, "Movies",
                2, 2, new Font("Arial", Font.BOLD, 14), Color.WHITE));
        moviePanel.setOpaque(false);

        try (Connection conn = DatabaseConnection.getConnection()) {
            String movieQuery = "SELECT MovieID, MovieName FROM Movies WHERE TheaterID = ?";
            PreparedStatement pstmt = conn.prepareStatement(movieQuery);
            pstmt.setInt(1, theaterID);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int movieID = rs.getInt("MovieID");
                String movieName = rs.getString("MovieName");

                JButton movieButton = new JButton(movieName);
                styleButton(movieButton);
                movieButton.addActionListener(e -> bookSeats(username, movieID, movieName));
                moviePanel.add(movieButton);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching movies: " + e.getMessage());
        }

        movieFrame.add(moviePanel, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton("Back");
        styleButton(backButton);
        backButton.addActionListener(e -> movieFrame.dispose());
        JPanel backPanel = new JPanel();
        backPanel.setOpaque(false);
        backPanel.add(backButton);
        movieFrame.add(backPanel, BorderLayout.SOUTH);

        movieFrame.setLocationRelativeTo(null); // Center the frame
        movieFrame.setVisible(true);
    }

    private static void bookSeats(String username, int movieID, String movieName) {
        JFrame bookingFrame = createBackgroundFrame("Booking Seats for " + movieName);

        // Main Panel for Seat Booking
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);

        // Title
        JLabel titleLabel = new JLabel("Enter Number of Seats:", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Larger text
        titleLabel.setForeground(Color.WHITE);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Input Panel with larger text field and spacing
        JPanel inputPanel = new JPanel();
        inputPanel.setOpaque(false);
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

        // Add vertical spacing
        inputPanel.add(Box.createVerticalStrut(50));

        // Larger text field
        JTextField seatsField = new JTextField(20); // Larger width
        seatsField.setFont(new Font("Arial", Font.PLAIN, 20)); // Larger font
        seatsField.setMaximumSize(new Dimension(300, 40)); // Fixed size
        seatsField.setAlignmentX(Component.CENTER_ALIGNMENT);

        inputPanel.add(seatsField);

        // Add vertical spacing below the text field
        inputPanel.add(Box.createVerticalStrut(20));

        // Confirm Button
        JButton confirmButton = new JButton("Confirm Booking");
        styleButton(confirmButton);
        confirmButton.setFont(new Font("Arial", Font.BOLD, 18)); // Larger button text
        confirmButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        inputPanel.add(confirmButton);

        mainPanel.add(inputPanel, BorderLayout.CENTER);
        bookingFrame.add(mainPanel, BorderLayout.CENTER);

        // Confirm Booking Action
        confirmButton.addActionListener(e -> {
            String seatsInput = seatsField.getText();
            if (seatsInput.isEmpty() || !seatsInput.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number of seats.");
                return;
            }

            int seats = Integer.parseInt(seatsInput);
            Random random = new Random();
            int bookingID = random.nextInt(10000);

            try (Connection conn = DatabaseConnection.getConnection()) {
                String bookingQuery = "INSERT INTO Bookings (UserID, MovieID, SeatsBooked) VALUES ((SELECT UserID FROM Users WHERE Username = ?), ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(bookingQuery);
                pstmt.setString(1, username);
                pstmt.setInt(2, movieID);
                pstmt.setInt(3, seats);

                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(null, "Booking Confirmed!\nBooking ID: " + bookingID +
                        "\nMovie: " + movieName + "\nSeats: " + seats, "Booking Confirmation", JOptionPane.INFORMATION_MESSAGE);
                bookingFrame.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error booking seats: " + ex.getMessage());
            }
        });

        // Back Button
        JButton backButton = new JButton("Back");
        styleButton(backButton);
        backButton.setFont(new Font("Arial", Font.BOLD, 16)); // Larger back button
        backButton.addActionListener(e -> bookingFrame.dispose());
        JPanel backPanel = new JPanel();
        backPanel.setOpaque(false);
        backPanel.add(backButton);
        bookingFrame.add(backPanel, BorderLayout.SOUTH);

        bookingFrame.setLocationRelativeTo(null); // Center the frame
        bookingFrame.setVisible(true);
    }

    private static JFrame createBackgroundFrame(String title) {
        JFrame frame = new JFrame(title);
        frame.setSize(780, 410);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        ImageIcon backgroundImage = new ImageIcon("src/background.jpeg");
        JLabel backgroundLabel = new JLabel(backgroundImage) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), null); // Scale the image
            }
        };
        backgroundLabel.setLayout(new BorderLayout());
        frame.setContentPane(backgroundLabel);

        return frame;
    }

    private static void styleButton(JButton button) {
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
    }
}
