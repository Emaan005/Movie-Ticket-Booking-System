package movieticketbooking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.*;

public class CancelBookingPanel {
    public static void showCancelBooking() {
        String bookingID = JOptionPane.showInputDialog(null, "Enter Booking ID to cancel:");

        if (bookingID != null && !bookingID.isEmpty()) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                String query = "DELETE FROM Bookings WHERE BookingID = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, Integer.parseInt(bookingID));

                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(null, "Booking cancelled successfully!",
                            "Cancellation Successful", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Booking ID.", 
                            "Cancellation Failed", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
