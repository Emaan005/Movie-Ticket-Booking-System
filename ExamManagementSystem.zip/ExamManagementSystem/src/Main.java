import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0; // Initialize choice to avoid "not initialized" error

        do {
            System.out.println("\n--- Exam Management System ---");
            System.out.println("1. View Student Records");
            System.out.println("2. Add New Student");
            System.out.println("3. Edit Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            // Read the user choice
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
            } else {
                System.out.println("Invalid input. Please enter a number between 1 and 5.");
                scanner.nextLine(); // Consume the invalid input
                continue;
            }

            switch (choice) {
                case 1:
                    StudentRecords.viewRecords();
                    break;
                case 2:
                    StudentRecords.addStudent();
                    break;
                case 3:
                    StudentRecords.editStudent(scanner); // Pass scanner to avoid reinitializing it
                    break;
                case 4:
                    StudentRecords.deleteStudent(scanner); // Pass scanner here as well
                    break;
                case 5:
                    System.out.println("Exiting... Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);
        scanner.close();
    }
}
