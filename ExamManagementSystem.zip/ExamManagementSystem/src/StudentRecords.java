import java.sql.*;
import java.util.Scanner;

public class StudentRecords {

    // MySQL connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ExamManagementSystem";
    private static final String DB_USER = "root"; // Replace with your DB username
    private static final String DB_PASSWORD = "zxasqw12"; // Replace with your DB password

    // Method to connect to the database
    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public static void viewRecords() {
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM students";
            ResultSet rs = stmt.executeQuery(query);

            System.out.println("\n--- Student Records ---");
            if (!rs.isBeforeFirst()) {
                System.out.println("No records found.");
            } else {
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("id") + ", Roll No: " + rs.getString("roll_number") +
                            ", Name: " + rs.getString("name") + ", Class: " + rs.getString("class") +
                            ", Marks: " + rs.getInt("marks"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addStudent() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Roll Number: ");
        String rollNumber = scanner.nextLine();
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Class: ");
        String studentClass = scanner.nextLine();
        System.out.print("Enter Marks: ");
        int marks = scanner.nextInt();

        String query = "INSERT INTO students (roll_number, name, class, marks) VALUES (?, ?, ?, ?)";

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, rollNumber);
            pstmt.setString(2, name);
            pstmt.setString(3, studentClass);
            pstmt.setInt(4, marks);
            pstmt.executeUpdate();

            System.out.println("Student added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void editStudent(Scanner scanner) {
        System.out.print("Enter Student ID to edit: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Marks: ");
        int newMarks = scanner.nextInt();

        String query = "UPDATE students SET marks = ? WHERE id = ?";

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, newMarks);
            pstmt.setInt(2, id);
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Student updated successfully!");
            } else {
                System.out.println("Student with ID " + id + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteStudent(Scanner scanner) {
        System.out.print("Enter Student ID to delete: ");
        int id = scanner.nextInt();

        String query = "DELETE FROM students WHERE id = ?";

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Student deleted successfully!");
            } else {
                System.out.println("Student with ID " + id + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Exam Management System ---");
            System.out.println("1. View Student Records");
            System.out.println("2. Add New Student");
            System.out.println("3. Edit Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewRecords();
                    break;
                case 2:
                    addStudent();
                    break;
                case 3:
                    editStudent(scanner);
                    break;
                case 4:
                    deleteStudent(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
